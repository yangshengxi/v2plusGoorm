// Package shadowsocks provides compatible functionality to Shadowsocks.
//
// Shadowsocks client and server are implemented as outbound and inbound respectively in V2Ray's term.
//
// R.I.P Shadowsocks
package shadowsocks

//go:generate go run github.com/v2fly/v2ray-core/v5/common/errors/errorgen
