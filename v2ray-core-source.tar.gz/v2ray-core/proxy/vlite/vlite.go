// Package vlite contains the integration code for VLite protocol variety
//
// VLite is currently an experimental protocol, its stability is not guaranteed.
package vlite
