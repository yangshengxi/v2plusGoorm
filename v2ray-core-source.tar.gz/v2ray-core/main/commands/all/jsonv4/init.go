package jsonv4

import "github.com/v2fly/v2ray-core/v5/main/commands/base"

func init() {
	base.RegisterCommand(cmdConvert)
}
